package basics;

public class NullReferenceVariable {

	private static Object obj;
	public static void main(String[] args) {
		System.out.println("Value of Object: "+ obj);
	}
}
